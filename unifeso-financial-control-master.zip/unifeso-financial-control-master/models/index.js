const User = require("./user_model");

module.exports = {
  User
};
